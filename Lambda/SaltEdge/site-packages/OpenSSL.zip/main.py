import logging
import json

# Facebook Page Token
# EAAYxS7zz3koBAOpFk1YePLYkPc81cMDMAwt8lKQnMCqH3TXZAMtuFL7VrY9Nfx6QKqMHbzsqaqu129D0cFj7irZCT40UZC61jrR3afRVgQkgnQmPZAbFpti48YXZCit8SqQOnZC7iGjDukZACZAXYRog4A8crUZA3zfteJMFi4GqD2zRz6S5R1P2Q

logger = logging.getLogger()
logger.setLevel(logging.INFO)

logger.info('Starting')


def handler(event, context):
    print(event)
    request = json.loads(event['body'])
    logger.info(request)
