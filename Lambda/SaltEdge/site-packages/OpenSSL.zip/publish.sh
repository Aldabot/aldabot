echo "Tuning Alda"
rm -r main.zip
zip -r9 main.zip * .*
aws lambda update-function-code --function-name SaltEdge --zip-file fileb://main.zip
